
#ifndef LTH1550_H
#define LTH1550_H
typedef enum {
    /** Channel 0 */
    IOT_ADC_CHANNEL_0,
    /** Channel 1 */
    IOT_ADC_CHANNEL_1,
    /** Channel 2 */
    IOT_ADC_CHANNEL_2,
    /** Channel 3 */
    IOT_ADC_CHANNEL_3,
    /** Channel 4 */
    IOT_ADC_CHANNEL_4,
    /** Channel 5 */
    IOT_ADC_CHANNEL_5,
    /** Channel 6 */
    IOT_ADC_CHANNEL_6,
    /** Channel 7 */
    IOT_ADC_CHANNEL_7,
    /** Button value */
    IOT_ADC_CHANNEL_BUTT,
} IotAdcChannelIndex;

void Lth1550Init(void);
int GetInfraredData(IotAdcChannelIndex idx);
int GetInfraredData(IotAdcChannelIndex idx);
float GetData(void);
#endif