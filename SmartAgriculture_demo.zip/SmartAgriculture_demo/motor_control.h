void LeftWheelForword(void);
void LeftWheelBackword(void);
void LeftWheelStop(void);
void RightWheelForword(void);
void RightWheelBackword(void);
void RightWheelStop(void);
void GA12N20Init(void);
