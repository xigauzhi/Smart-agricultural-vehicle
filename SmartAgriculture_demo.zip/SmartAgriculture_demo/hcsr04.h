#ifndef HCSR04_H
#define HCSR04_H

void Hcsr04Init(void);
float GetDistance(void);


#endif